﻿using Dapper;
using Helper;
using Interface.IRepository;
using Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ContactRepository: IContactRepository
    {
        #region Stored ProcNames
        private class StoredProcedures
        {
            public static string InsertUpdateContact = "uspInsertUpdateContact";
            public static string LoadContact = "uspLoadContact";
            public static string Delete = "uspDelete";
        }
        #endregion

        #region Insert Update Contact
        public async Task<ReturnStatus> InsertUpdateContact(ContactDetails contactDetails)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@ContactID", contactDetails.EncryptedContactID != "" ? Formatter.Decrypt(contactDetails.EncryptedContactID) : 0, dbType: DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@FirstName", contactDetails.FirstName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@LastName", contactDetails.LastName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Email", contactDetails.Email, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@PhoneNumber", contactDetails.PhoneNumber, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Address",contactDetails.Address, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@City", contactDetails.Address, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@State",contactDetails.State, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@Country", contactDetails.Country, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@PostalCode", contactDetails.PostalCode, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@OperationType", contactDetails.OperationType, dbType: DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@ActionDoneBy", contactDetails.ActionDoneBy, dbType: DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@ReturnResult", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);
            try
            {
                await new DBConnectivity().InsertAsync<ContactDetails>(StoredProcedures.InsertUpdateContact, parameters);
                return new ReturnStatus { ReturnResult = parameters.Get<int>("@ReturnResult") };
            }
            catch(Exception ex)
            {
                return new ReturnStatus { ReturnResult = 0 };
            }
        }
        #endregion

        #region Load Contact List
        // Load manage assistant grid data.
        public async Task<List<ContactDetails>> LoadContact(SearchContact searchContact)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@PageSize", searchContact.PageSize, dbType:DbType.Int32, direction:ParameterDirection.Input);
            parameters.Add("@PageNumber", searchContact.PageNumber, dbType: DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@SortColumn", searchContact.SortColumn, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@ContactID", searchContact.EncryptedContactID!=""?Formatter.Decrypt(searchContact.EncryptedContactID):0, dbType: DbType.Int32, direction: ParameterDirection.Input);
            var result = await new DBConnectivity().GetAllAsync<ContactDetails>(StoredProcedures.LoadContact, parameters);
            return result;
        }
        #endregion

        #region Insert Update Contact
        public async Task<ReturnStatus> DeleteContact(DeleteMasterDetail deleteMasterDetail)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@TableName", deleteMasterDetail.TableName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@ColumnName", deleteMasterDetail.ColumnName, dbType: DbType.String, direction: ParameterDirection.Input);
            parameters.Add("@ID", deleteMasterDetail.EncryptedID != "" ? Formatter.Decrypt(deleteMasterDetail.EncryptedID) : 0, dbType: DbType.Int32, direction: ParameterDirection.Input);
            parameters.Add("@ReturnResult", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);
            try
            {
                await new DBConnectivity().InsertAsync<ContactDetails>(StoredProcedures.Delete, parameters);
                return new ReturnStatus { ReturnResult = parameters.Get<int>("@ReturnResult") };
            }
            catch (Exception ex)
            {
                return new ReturnStatus { ReturnResult = 0 };
            }
        }
        #endregion
    }
}
