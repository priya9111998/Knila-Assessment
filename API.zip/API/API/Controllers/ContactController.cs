﻿using Interface.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Model;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace API.Controllers
{
    [Route("api/Contact")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly IContactService contactService;
        #region constructor
        // Constructor for ManageAssistantAPIController.
        public ContactController(IContactService contactService)
        {
            this.contactService = contactService;
        }
        #endregion
        #region Insert Update Contact
        [HttpGet("GenerateToken")]
        public IActionResult GenerateToken()
        {
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@345superSecretKey"));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
            var tokeOptions = new JwtSecurityToken(
                issuer: "https://localhost:7000",
                audience: "https://localhost:7000",
                claims: new List<Claim>(),
                expires: DateTime.Now.AddMinutes(5),
                signingCredentials: signinCredentials
            );
            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);
            return Ok(new AuthenticatedResponse { Token = tokenString });
        }
        #endregion
        #region Insert Update Contact
        [HttpPost("InsertUpdateContact")]
        public async Task<ReturnStatus> InsertUpdateContact(ContactDetails contactDetails)
        {
            return await contactService.InsertUpdateContact(contactDetails);
        }
        #endregion

        #region Load Contact
        [HttpPost("LoadContact")]
        public async Task<List<ContactDetails>> LoadContact(SearchContact searchContact)
        {
            return await contactService.LoadContact(searchContact);
        }
        #endregion

        #region Delete Contact
        [HttpPost("DeleteContact")]
        [Authorize]
        public async Task<ReturnStatus> DeleteContact(DeleteMasterDetail deleteMasterDetail)
        {
            return await contactService.DeleteContact(deleteMasterDetail);
        }
        #endregion
    }
}
