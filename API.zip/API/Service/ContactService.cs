﻿using Helper;
using Interface.IRepository;
using Interface.IService;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class ContactService: IContactService
    {
        private readonly IContactRepository contactRepository;

        public ContactService(IContactRepository contactRepository)
        {
            this.contactRepository = contactRepository;
        }
        #region Insert Update Contact
        public async Task<ReturnStatus> InsertUpdateContact(ContactDetails contactDetails)
        {
            return await contactRepository.InsertUpdateContact(contactDetails);
        }
        #endregion

        #region Load Contact
        public async Task<List<ContactDetails>> LoadContact(SearchContact searchContact)
        {
            List<ContactDetails> contactList = new();
            contactList = await contactRepository.LoadContact(searchContact);
            contactList.ForEach(item =>
            {
                item.EncryptedContactID = Formatter.Encrypt(item.ContactID.ToString());
                item.ContactID = 0;
            });
            return contactList;
        }
        #endregion

        #region Delete Contact
        public async Task<ReturnStatus> DeleteContact(DeleteMasterDetail deleteMasterDetail)
        {
            return await contactRepository.DeleteContact(deleteMasterDetail);
        }
        #endregion
    }
}
