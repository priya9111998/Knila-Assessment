﻿using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public class DBConnectivity
    {
        private readonly string connectionString;
        private IDbConnection dbConnection;
        public DBConnectivity()
        {
            this.connectionString = DBConfig.connectionString;
        }
        #region CONNECTION
        private IDbConnection OpenConnection()
        {
            if (dbConnection == null || dbConnection.State != ConnectionState.Open)
            {
                dbConnection = new SqlConnection(connectionString);
                dbConnection.Open();
            }
            return dbConnection;
        }
        #endregion

        #region INSERT
        public async Task<int> InsertAsync<T>(string storedProcedure, DynamicParameters parameters)
        {
            using (var connection = OpenConnection())
            {
                return await connection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
            }
        }
        #endregion

        #region GET ALL
        public async Task<List<T>> GetAllAsync<T>(string storedProcedure, DynamicParameters parameters)
        {
            using (var connection = OpenConnection())
            {
                var result = await connection.QueryAsync<T>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
                return result.ToList();

            }
        }
        #endregion
    }
}
