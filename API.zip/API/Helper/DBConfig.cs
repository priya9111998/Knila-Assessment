﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public class DBConfig
    {
        public static string connectionString = GetConnectionString();
        public static string GetConnectionString()
        {
            var configuration = new ConfigurationBuilder()
            .AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"), optional: false)
            .Build();
            return configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value;
        }
    }
}
