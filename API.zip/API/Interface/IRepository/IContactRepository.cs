﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface.IRepository
{
    public interface IContactRepository
    {
        Task<ReturnStatus> InsertUpdateContact(ContactDetails contactDetails);
        Task<List<ContactDetails>> LoadContact(SearchContact searchContact);
        Task<ReturnStatus> DeleteContact(DeleteMasterDetail deleteMasterDetail);
    }
}
