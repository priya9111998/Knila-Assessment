export class DeleteMasterDetail {
    TableName: String = "";
    ColumnName: String = "";
    EncryptedID: String = "";
}