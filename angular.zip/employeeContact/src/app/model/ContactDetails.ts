export class ContactDetails {
    RowID: Number = 0;
    ContactID: Number = 0;
    EncryptedContactID: String = "";
    FirstName: String = "";
    LastName: String = "";
    Email: String = "";
    PhoneNumber: String = "";
    Address: String = "";
    City: String = "";
    State: String = "";
    Country: String = "";
    PostalCode: String = "";
    OperationType: Number = 0;
    ActionDoneBy: Number = 0;
    HighlightFlag: Boolean = false;
}