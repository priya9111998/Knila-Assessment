export class SearchContact {
    EncryptedContactID: String = "";
    PageSize: Number = 10;
    PageNumber: Number = 1;
    SortColumn!: String;
}