///service :
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//env file
import { API_EndPoints } from '../env';
//user defined models
import { SearchContact } from './../model/SearchContact';
import { DeleteMasterDetail } from '../model/DeleteMasterDetail';

@Injectable({
    providedIn: 'root'
})
export class ContactService {
    constructor(private http: HttpClient) { }

    //JWT Token setter
    setAuthorizationHeader(): HttpHeaders {
        if (localStorage.getItem('jwtToken'))
            return new HttpHeaders({ 'Authorization': `Bearer ${localStorage.getItem('jwtToken')}` });
        else
            return new HttpHeaders();
    }

    GenerateToken(): Observable<any> {
        return this.http.get(API_EndPoints.GENERATE_TOKEN);
    }

    InsertUpdateContact(contact: any): Observable<any> {
        return this.http.post(API_EndPoints.INSERT_UPDATE_CONTACT, contact);
    }

    LoadContact(contact: SearchContact): Observable<any> {
        return this.http.post(API_EndPoints.LOAD_CONTACT, contact);
    }

    DeleteContact(contact: DeleteMasterDetail) {
        const headers = this.setAuthorizationHeader();
        return this.http.post(API_EndPoints.DELETE_CONTACT, contact, { headers: headers });
    }
}