///interceptor:

import { HttpInterceptor, HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
//env 
import { environment } from '../env';

@Injectable({
    providedIn: 'root'
})
export class HttpRequestCallService implements HttpInterceptor {
    constructor() { }
    private jwtToken: string | null = null;

    intercept(req: HttpRequest<any>, next: HttpHandler):
        Observable<HttpEvent<any>> {
        const newreq = req.clone({ url: environment.apiUrl + req.url })
        return next.handle(newreq)
            .pipe(
                tap((result: any) => {
                    if (result.body != undefined && result.body.Token != undefined) {
                        //set token in storage
                        this.jwtToken = result.body.Token;
                        localStorage.setItem('jwtToken', this.jwtToken!);
                    }
                    console.log("Success", result);
                },
                    (error) => {
                        console.log("Failure", error);
                    }
                )
            )
    }
}