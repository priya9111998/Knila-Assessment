///service :
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//npms
import Swal from 'sweetalert2';

@Injectable({
    providedIn: 'root'
})
export class SwalService {
    constructor(private http: HttpClient) { }

    confirmDeletion(): Promise<void> {
        return new Promise((resolve, reject) => {
            Swal.fire({
                title: 'Are you sure you want to delete?',
                text: 'You cannot undo this action.',
                icon: 'warning',
                showCancelButton: true,
                allowOutsideClick: false,
                allowEscapeKey: false,
                confirmButtonColor: '#b7473c',
                confirmButtonText: 'Yes, delete it!',
            }).then((result) => {
                if (result.isConfirmed)
                    resolve();
                else
                    reject();
            });
        });
    }

    SavedOrUpdatedSuccessfully(msg: String): Promise<void> {
        return new Promise((resolve, reject) => {
            Swal.fire({
                title: msg,
                confirmButtonText: 'OK',
                icon: 'success',
                allowOutsideClick: false,
                confirmButtonColor: '#348185'
            }).then((result) => {
                if (result.isConfirmed)
                    resolve();
                else
                    reject();
            });
        });
    }
}