import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
//npms
import { AgGridAngular } from 'ag-grid-angular';
//user defined modules
import { ContactModule } from './Contact/Contact.module';
//user defined component
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
//interceptor
import { HttpRequestCallService } from './service/HttpRequestCallService.service';
@NgModule({
  declarations: [
    AppComponent
    , HeaderComponent
    , FooterComponent
  ],
  imports: [
    BrowserModule
    , NgbModule
    , BrowserAnimationsModule
    , AppRoutingModule
    , HttpClientModule
    , ContactModule
    , AgGridAngular
  ],
  exports: [
    BrowserModule],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: HttpRequestCallService,
    multi: true
  },],
  bootstrap: [AppComponent]
})
export class AppModule { }
