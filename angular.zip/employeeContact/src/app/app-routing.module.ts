import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//component
import { ContactListComponent } from './Contact/contact-list/contact-list.component';

const routes: Routes = [
  { path: '', component: ContactListComponent },
  {
    path: ''
    , children: [
      { path: 'contact', loadChildren: () => import('./Contact/Contact.module').then(m => m.ContactModule) },
    ]
  }
  , { path: '**', component: ContactListComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
