import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
//models
import { ContactDetails } from 'src/app/model/ContactDetails';
import { SearchContact } from 'src/app/model/SearchContact';
import { DeleteMasterDetail } from 'src/app/model/DeleteMasterDetail';
//services
import { ContactService } from 'src/app/service/contactservice.service';
import { SwalService } from 'src/app/service/swalservice.service';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  //variables declaration
  public contactDetails = new ContactDetails();
  public searchContact = new SearchContact();
  public deleteMasterDetail = new DeleteMasterDetail();
  private listsubscription: Subscription = new Subscription();
  private tokensubscription: Subscription = new Subscription();
  private editsubscription: Subscription = new Subscription();
  private deletesubscription: Subscription = new Subscription();
  public contactList: any;
  public isAscending: boolean = true;
  public sortBy: string = 'FirstName';
  constructor(
    public router: Router
    , public contactService: ContactService
    , public modal: NgbModal
    , public swalService: SwalService
  ) {
  }

  ngOnInit() {
    this.LoadContact("CreatedDate DESC");
  }

  //load list
  LoadContact(sortColumn: String) {
    this.searchContact.SortColumn = sortColumn;
    this.listsubscription.add(this.contactService.LoadContact(this.searchContact).subscribe((contact: any) => {
      this.contactList = contact;
    }));
  }

  //sort table
  ToggleSort(column: string) {
    if (this.sortBy === column)
      this.isAscending = !this.isAscending;
    else {
      this.sortBy = column;
      this.isAscending = true;
    }
    this.LoadContact(this.sortBy + " " + (this.isAscending == false ? "desc" : "asc"));
  }

  //add contact
  AddNewContact() {
    this.tokensubscription.add(this.contactService.GenerateToken().subscribe(data => {
      this.router.navigateByUrl("/contact/add-contact");
    }));
  }

  //edit contact
  EditContact(content: any, EncryptedContactID: String) {
    this.searchContact.EncryptedContactID = EncryptedContactID;
    this.editsubscription.add(this.contactService.LoadContact(this.searchContact).subscribe((contact: any) => {
      this.contactDetails = contact[0];
      this.modal.open(content, { ariaLabelledBy: 'modal-basic-title' });
    }));
  }

  //delete contact
  DeleteContact(contactID: string) {
    this.deleteMasterDetail.EncryptedID = contactID;
    this.deleteMasterDetail.TableName = "Contact";
    this.deleteMasterDetail.ColumnName = "ContactID";
    this.swalService.confirmDeletion().then(() => {
      this.deletesubscription.add(this.contactService.DeleteContact(this.deleteMasterDetail).subscribe((result: any) => {
        if (result.ReturnResult) {
          this.swalService.SavedOrUpdatedSuccessfully("Contact has been deleted successfully").then(() => {
            this.LoadContact("CreatedDate DESC");
          });
        }
      }));
    });
  }

  //close modal after edit from child component
  CloseEditModal(closeFalg: Number) {
    if (closeFalg) {
      this.modal.dismissAll();
      this.searchContact = new SearchContact();
      this.LoadContact("CreatedDate DESC");
    }
  }

  CloseModal(): void {
    this.modal.dismissAll();
  }

  ngOnDestroy(): void {
    this.listsubscription.unsubscribe();
    this.tokensubscription.unsubscribe();
    this.editsubscription.unsubscribe();
    this.deletesubscription.unsubscribe();
  }
}