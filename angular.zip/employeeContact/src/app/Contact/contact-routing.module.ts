import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//user defined components
import { ContactListComponent } from './contact-list/contact-list.component';
import { AddContactComponent } from './add-contact/add-contact.component';
//env
import { Web_EndPoints } from '../env';

const routes: Routes = [
    { path: '', component: ContactListComponent }
    , { path: Web_EndPoints.CONTACT_LIST, component: ContactListComponent }
    , { path: Web_EndPoints.ADD_CONTACT, component: AddContactComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ContactRoutingModule { }
