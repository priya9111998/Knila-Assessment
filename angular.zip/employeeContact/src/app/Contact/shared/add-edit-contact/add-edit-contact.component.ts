import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

//user defined models
import { ContactDetails } from 'src/app/model/ContactDetails';

//user defined services
import { ContactService } from 'src/app/service/contactservice.service';
import { SwalService } from 'src/app/service/swalservice.service';

@Component({
  selector: 'app-add-edit-contact',
  templateUrl: './add-edit-contact.component.html',
  styleUrls: ['./add-edit-contact.component.css']
})
export class AddEditContactComponent implements OnInit {
  constructor(
    public contactService: ContactService
    , public swalService: SwalService
    , public router: Router
  ) { }
  //variables
  @Input() contactDetails: ContactDetails = new ContactDetails();
  @Output() CloseModal = new EventEmitter<Number>();
  private subscription: Subscription = new Subscription();
  ngOnInit(): void { }

  SubmitContact(f: NgForm) {
    if (f.invalid) {
      return;
    }
    this.contactDetails.OperationType = this.contactDetails.EncryptedContactID ? 2 : 1;
    this.subscription.add(
      this.contactService.InsertUpdateContact(this.contactDetails).subscribe((result: any) => {
        if (result.ReturnResult) {
          this.CloseModal.emit(1);
          this.swalService.SavedOrUpdatedSuccessfully("Contact has been saved successfully").then(() => {
            if (result.ReturnResult === 1 || result.ReturnResult === 2) {
              this.router.navigateByUrl("/contact/contact-list");
            }
          });
        }
      })
    );
  }

  BackToList() {
    this.router.navigateByUrl("/contact/contact-list");
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
