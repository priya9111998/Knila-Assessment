import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';

//user defined directives
import { NumberDirective } from '../directive/number-directive.directive';

//user defined components
import { ContactListComponent } from './contact-list/contact-list.component';
import { AddEditContactComponent } from './shared/add-edit-contact/add-edit-contact.component';
import { AddContactComponent } from './add-contact/add-contact.component';

//user defined modules
import { ContactRoutingModule } from './contact-routing.module';

@NgModule({
    declarations: [ContactListComponent
        , AddEditContactComponent
        , AddContactComponent
        , NumberDirective],
    imports: [
        CommonModule
        , ContactRoutingModule
        , FormsModule
        , ReactiveFormsModule
        , AgGridAngular
    ],
    providers: [],
    exports: [ContactListComponent
        , AddEditContactComponent
        , AddContactComponent
        , NumberDirective]
})
export class ContactModule { }
