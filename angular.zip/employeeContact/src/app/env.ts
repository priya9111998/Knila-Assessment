export const environment = {
    production: false,
    apiUrl: "https://localhost:7000/api/"
};

export const API_EndPoints = {
    GENERATE_TOKEN: "Contact/GenerateToken"
    , INSERT_UPDATE_CONTACT: "Contact/InsertUpdateContact"
    , LOAD_CONTACT: "Contact/LoadContact"
    , DELETE_CONTACT: "Contact/DeleteContact"
};


export const Web_EndPoints = {
    CONTACT_LIST: "contact-list"
    , ADD_CONTACT: "add-contact"
};